"""Core application package."""
